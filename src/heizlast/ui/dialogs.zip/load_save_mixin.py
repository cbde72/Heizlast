import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from ..domain.models import RoomModel
from .graphics import snap_m

from PySide6.QtWidgets import QFileDialog, QMessageBox

from ..core.config import CSV_DELIMITER, DEFAULT_FACTOR, DEFAULT_U
from ..core.csv_io import load_elements, load_rooms, save_elements, save_rooms
from ..core.element_metrics import ElementMetricsService
from ..core.geometry import build_auto_walls_shared_merge
from ..core.heatload import ensure_auto_decks
from ..domain.models import ElementModel, RoomModel
from ..configs.project_config import ProjectCfg, load_project_cfg, save_project_cfg

class MainWindowLoadSaveMixin:
    def _project_json_path_for_rooms(self, rooms_csv_path: Path) -> Path:
        """Erzeugt den Pfad zur Projekt-JSON-Datei."""
        return rooms_csv_path.with_name(f"{rooms_csv_path.stem}.project.json")

    def _derive_elements_path(self, rooms_path: Path) -> Path:
        """Leitet den Pfad zur Element-CSV aus dem Raum-CSV-Pfad ab."""
        name = rooms_path.name
        stem = rooms_path.stem
        if name.lower() == "rooms.csv":
            return rooms_path.with_name("elements.csv")
        if stem.lower().endswith("_rooms"):
            return rooms_path.with_name(stem[:-6] + "_elements.csv")
        return rooms_path.with_name(stem + "_elements.csv")

    def _new_room_id(self, floor: str) -> str:
        """Erzeugt eine neue eindeutige Raum-ID."""
        base = (floor or "EG").upper()
        i = 1
        while True:
            rid = f"{base}_{i}"
            if rid not in self.rooms:
                return rid
            i += 1

    # ---------------- Auswahl und Formular ----------------

    def _normalize_room_geometry(self, r: RoomModel) -> None:
         """
         Single Source of Truth: Raumgeometrie (x/y/w/h/height).
         Diese Funktion ist die zentrale Stelle, die garantiert:
           - w/h immer > 0 und >= MIN_SIZE
           - x/y gesnapt
           - height gesetzt
         """
         if r is None:
             return

         MIN_SIZE = 0.20

         try:
             r.x_m = snap_m(float(r.x_m or 0.0))
             r.y_m = snap_m(float(r.y_m or 0.0))

             # w/h immer positiv und Mindestmaß
             r.w_m = max(MIN_SIZE, snap_m(abs(float(r.w_m or MIN_SIZE))))
             r.h_m = max(MIN_SIZE, snap_m(abs(float(r.h_m or MIN_SIZE))))

             # Raumhöhe absichern
             if float(getattr(r, "height_m", 0.0) or 0.0) <= 1e-6:
                 r.height_m = 2.50

             r.recompute_volume()
         except Exception:
             # Im Zweifel nichts crashen lassen
             pass

    def _on_load(self):
        """Lädt CSV-Dateien."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            "rooms.csv wählen",
            str(self._project_rooms_path.parent if self._project_rooms_path else Path.cwd()),
            "CSV (*.csv)"
        )
        if not path:
            return
        rooms_path = Path(path)
        elements_path = self._derive_elements_path(rooms_path)

        try:
            rooms = load_rooms(str(rooms_path), delimiter=CSV_DELIMITER)
            elements = load_elements(str(elements_path), delimiter=CSV_DELIMITER) if elements_path.exists() else []
        except Exception as e:
            QMessageBox.critical(self, "Load error", str(e))
            return

        self.rooms = {r.id: r for r in rooms}
        self.elements = elements

        # <-- WICHTIG:
        if hasattr(self, "metrics") and self.metrics is not None:
            self.metrics.bind(self.rooms, self.elements)
        else:
            self.metrics = ElementMetricsService(self.rooms, self.elements)
        self._project_rooms_path = rooms_path
        self._project_elements_path = elements_path

        # Projekt-Konfiguration laden
        cfg_path = self._project_json_path_for_rooms(rooms_path)
        if cfg_path.exists():
            try:
                self.project_cfg = load_project_cfg(cfg_path)
            except Exception:
                self.project_cfg = ProjectCfg()
        else:
            self.project_cfg = ProjectCfg()

        # Einstellungen synchronisieren
        self.t_out_c = float(self.project_cfg.t_out_c)
        want_outer = (self.project_cfg.floor_area_mode == "outer")
        if hasattr(self, "cb_area_ref_outer"):
            self.cb_area_ref_outer.blockSignals(True)
            self.cb_area_ref_outer.setChecked(bool(want_outer))
            self.cb_area_ref_outer.blockSignals(False)
        if hasattr(self, "act_area_ref_outer"):
            self.act_area_ref_outer.blockSignals(True)
            self.act_area_ref_outer.setChecked(bool(want_outer))
            self.act_area_ref_outer.blockSignals(False)

        # Automatische Decken ergänzen
        snap = self._snapshot_auto_deck_overrides()
        try:
            cfg = self.project_cfg

            ensure_auto_decks(
                self.rooms.values(),
                self.elements,
                u_kellerdecke_w_m2k=float(cfg.u_kellerdecke_w_m2k),
                u_eg_geschossdecke_w_m2k=float(cfg.u_eg_geschossdecke_w_m2k),
                u_dg_geschossdecke_w_m2k=float(cfg.u_dg_geschossdecke_w_m2k),
                )
        except Exception:
            pass
        self._restore_auto_deck_overrides(snap)


        self._rebuild_all_graphics()
        self._update_statusbar_summary()
        self.statusBar().showMessage(f"Geladen: {rooms_path.name}", 3500)

    def _save_to_paths(self, rooms_path: Path, elements_path: Path) -> bool:
        """Speichert die Daten in den angegebenen Pfaden."""
        try:
            save_rooms(str(rooms_path), list(self.rooms.values()), delimiter=CSV_DELIMITER)
            save_elements(str(elements_path), self.elements, delimiter=CSV_DELIMITER)
            self._project_rooms_path = rooms_path
            self._project_elements_path = elements_path

            try:
                cfg_path = self._project_json_path_for_rooms(rooms_path)
                save_project_cfg(cfg_path, self.project_cfg)
            except Exception:
                pass

            self._update_statusbar_summary()
            self.statusBar().showMessage(f"Gespeichert: {rooms_path.name}", 3500)
            return True
        except Exception as e:
            QMessageBox.critical(self, "Save error", str(e))
            return False

    def _on_save(self):
        """Speichert die Daten."""
        if not self._project_rooms_path:
            self._on_save_as()
            return
        rooms_path = self._project_rooms_path
        elements_path = self._project_elements_path or self._derive_elements_path(rooms_path)
        self._save_to_paths(rooms_path, elements_path)

    def _on_save_as(self):
        """Speichert die Daten unter einem neuen Namen."""
        start_dir = str(self._project_rooms_path.parent) if self._project_rooms_path else str(Path.cwd())
        start_name = str(self._project_rooms_path) if self._project_rooms_path else str(Path(start_dir) / "rooms.csv")
        path, _ = QFileDialog.getSaveFileName(self, "CSV speichern unter… (rooms)", start_name, "CSV (*.csv)")
        if not path:
            return
        rooms_path = Path(path)
        if rooms_path.suffix.lower() != ".csv":
            rooms_path = rooms_path.with_suffix(".csv")
        elements_path = self._derive_elements_path(rooms_path)
        self._save_to_paths(rooms_path, elements_path)
